import mysql.connector

def get_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="Kapil@123",
        database="bank_db",
        port=3307
    )