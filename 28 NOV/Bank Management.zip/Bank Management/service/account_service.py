
from dao.account_dao import AccountDAO
class AccountService:

    def __init__(self):
        self.dao = AccountDAO()

    def create_account(self, acc_no, name, balance, acc_type):
        if acc_no <= 0 or not name.strip() or balance < 0:
            print("Invalid account details!")
            return

        acc = (acc_no, name, balance, acc_type)
        self.dao.create_account(acc)
        print("Account created successfully!")

    def update_account(self, acc_no, name, balance):
        if not name.strip() or balance < 0:
            print("Invalid details!")
            return

        result = self.dao.update_account(acc_no, name, balance)
        print("Account updated!" if result else "Account not found!")

    def delete_account(self, acc_no):
        result = self.dao.delete_account(acc_no)
        print("Account deleted!" if result else "Account not found!")

    def search_account(self, acc_no):
        result = self.dao.search_account(acc_no)

        if result:
            print("Account Details:", result)
        else:
            print("Account not found!")

    def display_accounts(self):
        result = self.dao.display_accounts()

        for account in result:
            print(account)
