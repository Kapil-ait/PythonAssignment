
from database.connection import get_connection

class AccountDAO:

    def create_account(self, acc):
        con = get_connection()
        cur = con.cursor()

        query = "INSERT INTO account VALUES (%s,%s,%s,%s)"
        cur.execute(query, acc)

        con.commit()
        con.close()

    def update_account(self, acc_no, name, balance):
        con = get_connection()
        cur = con.cursor()

        query = """
        UPDATE account
        SET holder_name=%s, balance=%s
        WHERE account_no=%s
        """
        cur.execute(query, (name, balance, acc_no))

        con.commit()
        count = cur.rowcount
        con.close()
        return count

    def delete_account(self, acc_no):
        con = get_connection()
        cur = con.cursor()

        query = "DELETE FROM account WHERE account_no=%s"
        cur.execute(query, (acc_no,))

        con.commit()
        count = cur.rowcount
        con.close()
        return count

    def search_account(self, acc_no):
        con = get_connection()
        cur = con.cursor()

        query = "SELECT * FROM account WHERE account_no=%s"
        cur.execute(query, (acc_no,))

        result = cur.fetchone()
        con.close()
        return result

    def display_accounts(self):
        con = get_connection()
        cur = con.cursor()

        cur.execute("SELECT * FROM account")
        result = cur.fetchall()

        con.close()
        return result
