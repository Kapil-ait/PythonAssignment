
from service.account_service import AccountService
service = AccountService()

while True:

    print("\n===== BANK ACCOUNT MANAGEMENT SYSTEM =====")
    print("1. Create Account")
    print("2. Update Account")
    print("3. Delete Account")
    print("4. Search Account")
    print("5. Display All Accounts")
    print("6. Exit")

    choice = int(input("Enter your choice: "))

    if choice == 1:
        acc_no = int(input("Enter Account Number: "))
        name = input("Enter Holder Name: ")
        balance = float(input("Enter Balance: "))
        acc_type = input("Enter Account Type: ")

        service.create_account(acc_no, name, balance, acc_type)

    elif choice == 2:
        acc_no = int(input("Enter Account Number: "))
        name = input("Enter New Holder Name: ")
        balance = float(input("Enter New Balance: "))

        service.update_account(acc_no, name, balance)

    elif choice == 3:
        acc_no = int(input("Enter Account Number: "))
        service.delete_account(acc_no)

    elif choice == 4:
        acc_no = int(input("Enter Account Number: "))
        service.search_account(acc_no)

    elif choice == 5:
        service.display_accounts()

    elif choice == 6:
        print("Thank you for using Bank Management System!")
        break

    else:
        print("Invalid choice! Please try again.")
